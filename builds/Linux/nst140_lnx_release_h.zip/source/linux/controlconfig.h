/*
	NEStopia / Linux
	Port by R. Belmont
	
	controlconfig.h - control configurator
*/

#ifndef CONTROLCONFIG_H
#define CONTROLCONFIG_H

void run_configurator(InputDefT *ctl_list, int itemToSet, int usejoys);

#endif

